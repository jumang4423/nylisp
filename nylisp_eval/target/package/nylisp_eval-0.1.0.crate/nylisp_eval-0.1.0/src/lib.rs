
fn hello() {
    println!("Hello, world!");
}
